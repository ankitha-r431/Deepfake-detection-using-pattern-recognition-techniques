import React, { useState } from 'react';
import { Shield, AlertTriangle, Info } from 'lucide-react';
import { UploadZone } from './components/UploadZone';
import { ResultCard } from './components/ResultCard';

function App() {
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [result, setResult] = useState<null | {
    isReal: boolean;
    confidence: number;
    type: string;
  }>(null);

  const handleFileSelect = async (file: File) => {
    setIsAnalyzing(true);
    // Simulated analysis - in production, this would call your actual API
    setTimeout(() => {
      setResult({
        isReal: Math.random() > 0.5,
        confidence: Math.floor(Math.random() * 30) + 70,
        type: file.type.split('/')[0],
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-50">
      <header className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 py-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between">
            <div className="flex items-center">
              <Shield className="h-8 w-8 text-blue-600" />
              <h1 className="ml-2 text-2xl font-bold text-gray-900">DeepFake Detective</h1>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-7xl mx-auto px-4 py-12 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-gray-900 sm:text-4xl">
            Detect Manipulated Media
          </h2>
          <p className="mt-3 text-xl text-gray-500">
            Upload your media file to check its authenticity using our advanced AI analysis
          </p>
        </div>

        <div className="flex flex-col items-center space-y-8">
          <UploadZone onFileSelect={handleFileSelect} isAnalyzing={isAnalyzing} />
          
          {isAnalyzing && (
            <div className="flex items-center space-x-2">
              <div className="animate-spin rounded-full h-6 w-6 border-b-2 border-blue-600"></div>
              <span className="text-gray-600">Analyzing your media...</span>
            </div>
          )}

          {result && <ResultCard result={result} />}

          <div className="max-w-2xl w-full mt-8">
            <div className="bg-white rounded-lg shadow-md p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4 flex items-center">
                <Info className="w-5 h-5 mr-2 text-blue-500" />
                How it works
              </h3>
              <div className="space-y-4">
                <p className="text-gray-600">
                  Our advanced AI system analyzes patterns across different types of media to detect signs of manipulation:
                </p>
                <ul className="list-disc list-inside space-y-2 text-gray-600 ml-4">
                  <li>Video analysis for frame inconsistencies</li>
                  <li>Audio fingerprinting for voice manipulation</li>
                  <li>Image metadata and pixel-level examination</li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </main>

      <footer className="bg-white mt-12">
        <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
          <div className="flex justify-center items-center text-gray-500">
            <AlertTriangle className="w-4 h-4 mr-2" />
            <p className="text-sm">
              This is a demonstration. For production use, connect to your actual deepfake detection API.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;